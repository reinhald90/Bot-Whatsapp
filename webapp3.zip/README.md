# Web2APK Pro Bot Gen 3 - VPS Edition

Bot Telegram + Web Dashboard untuk konversi website menjadi aplikasi Android (APK) native.

## ✨ Fitur Baru Gen 3

| Fitur | Telegram Bot | Web Dashboard |
|-------|:------------:|:-------------:|
| **URL to APK** | ✅ | ✅ |
| **ZIP Build (Flutter/Android)** | ✅ | ✅ |
| **Custom Icon** | ✅ | ✅ |
| **Server Status** | ✅ | ✅ |
| **Build Queue** | ✅ | ✅ |
| **Auto IP Detection** | - | ✅ |
| **Server Specs Display** | - | ✅ |
| **File Limit 2GB** | ✅* | ✅ |

> *Dengan Local Bot API Server

---

## 📋 Requirements

| Requirement | Version | Keterangan |
|-------------|---------|------------|
| **Node.js** | 18+ | Runtime JavaScript |
| **Java JDK** | 17+ | Untuk compile Android |
| **Gradle** | 9.x | Build tool |
| **Android SDK** | 34 | SDK & Build Tools |
| **Flutter** | 3.x | Untuk ZIP build Flutter |
| **Storage** | 2GB+ | Untuk SDK & dependencies |

**OS Support:** Windows 10/11, Ubuntu/Debian (VPS)

---

## 🚀 Instalasi Cepat
```
Masuk Vps
- Ketik mkdir /home
- ketik cd /home
```
### Linux/VPS (Ubuntu/Debian)

```bash
chmod +x setup.sh
./setup.sh

```
> ℹ️ **Script akan otomatis:**
>
> - Install npm dependencies
> - Download & Install Android SDK
> - Set JAVA_HOME & ANDROID_HOME
> - Install Build Tools & Platform
> - Install Flutter SDK

### Install Gradle (jika belum ada)

**Linux:**

```bash
sudo apt install gradle
```

---

## 🖥️ Deploy di VPS (Ubuntu/Debian)

### 1. Download & Run Setup Script

```bash
# Download script
wget https://raw.githubusercontent.com/yourusername/web2apk/main/scripts/setup-vps.sh

# Jalankan
chmod +x setup-vps.sh
./setup-vps.sh
```

> ℹ️ **Script akan otomatis install:**
>
> - Node.js 20, Java 17, Gradle
> - Android SDK 34 + Build Tools
> - Flutter SDK
> - PM2 untuk process manager

### 2. Clone & Setup Project

```bash
git clone https://github.com/yourusername/web2apk.git
cd web2apk
npm install
cp .env.example .env
nano .env  # Edit dan isi BOT_TOKEN
```

### 3. Konfigurasi Anti-Clone Protection

> ⚠️ **WAJIB untuk keamanan!** Ini mencegah source code Anda di-clone dan dijalankan oleh orang lain.

**1. Generate License Key:**

```bash
node -e "console.log(require('crypto').randomUUID())"
```

Contoh output: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

**2. Generate Anti-Clone Secret:**

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Contoh output: `8f7a3b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a`

**3. Edit file `.env`:**

```env
# Anti-Clone Protection
ALLOWED_DOMAINS=localhost,127.0.0.1,yourdomain.com
SERVER_LICENSE_KEY=a1b2c3d4-e5f6-7890-abcd-ef1234567890
ANTI_CLONE_SECRET=8f7a3b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a
```

| Variable | Keterangan |
|----------|------------|
| `ALLOWED_DOMAINS` | Domain yang diizinkan akses (pisah dengan koma) |
| `SERVER_LICENSE_KEY` | **WAJIB** - Key unik dari `randomUUID()` |
| `ANTI_CLONE_SECRET` | **WAJIB** - Secret dari `randomBytes(32)` |

> 💡 **Tips:**
> - Simpan kedua key di tempat aman
> - Jangan share ke siapapun
> - Jika diganti, semua instance yang berjalan akan berhenti

### 4. Jalankan dengan PM2

```bash
pm2 start src/bot.js --name "web2apk"
pm2 startup && pm2 save

# Monitoring
pm2 logs web2apk
```

### 5. Setup Local Bot API Server (Untuk File 2GB)

> ⚠️ **Optional** - Hanya diperlukan jika ingin menerima/mengirim file >20MB/50MB

Local Bot API Server memungkinkan bot menerima dan mengirim file hingga **2GB**!

**1. Dapatkan API credentials dari [my.telegram.org](https://my.telegram.org)**

**2. Jalankan script setup:**

```bash
chmod +x scripts/setup-local-api.sh
sudo ./scripts/setup-local-api.sh API_ID API_HASH
```

> Script akan otomatis install dependencies, build server, dan membuat systemd service.

**3. Tambahkan ke `.env`:**

```env
LOCAL_API_URL=http://localhost:8081
API_ID=your_api_id
API_HASH=your_api_hash
```

**4. Restart bot:**

```bash
pm2 restart web2apk
```

**Useful Commands:**

```bash
# Check status
systemctl status telegram-bot-api

# View logs
journalctl -u telegram-bot-api -f

# Restart
systemctl restart telegram-bot-api
```